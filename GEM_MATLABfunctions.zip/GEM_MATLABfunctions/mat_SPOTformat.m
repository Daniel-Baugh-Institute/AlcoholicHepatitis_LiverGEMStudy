%    FBAMODEL = READ_SBML(SBMLFNAME) reads the SBML file SBMLFNAME.txt
%    and returns the FBA model contained in it as FBAMODEL

% by Desmond S. Lun on Oct, 9, 2012
function fbamodel = mat_SPOTformat(sbmlfname) 

addpath(genpath('GEMGeneration'))
addpath(genpath('FluxBalanceAnalysis'))

model = load(sbmlfname);
model_name = erase(sbmlfname,'.mat');
model = getfield(model,model_name);
fbamodel.nrxn = length(model.rxns); 
fbamodel.nmetab = length(model.mets); 
fbamodel.S = model.S; 
fbamodel.rxns = model.rxns; 
fbamodel.metabs = model.mets; 
fbamodel.f = zeros(fbamodel.nrxn, 1); 
fbamodel.g = zeros(fbamodel.nrxn, 1); 
fbamodel.present = true(fbamodel.nrxn, 1);


fbamodel.vmin = model.lb; 
fbamodel.vmax = model.ub; 
for i = 1:length(fbamodel.vmin)
    if fbamodel.vmin(i) == -1000
        fbamodel.vmin(i) = -Inf;
    end
    if fbamodel.vmax(i) == 1000
        fbamodel.vmax(i) = Inf;
    end
end

fbamodel.pts = model.grRules';
fbamodel.pts = strcat('(',fbamodel.pts,')');
for i = 1:length(fbamodel.pts)
    if fbamodel.pts{i}=="()"
        fbamodel.pts{i}='';
    end
end

fbamodel.G = sparse(0, fbamodel.nrxn);
ipt = 1;

boundary = zeros(fbamodel.nmetab, 1);

for imetab = 1:fbamodel.nmetab 
    fbamodel.metabs{imetab} = model.mets(imetab); 
    fbamodel.metabname{imetab} = model.metNames(imetab); 
    
    boundary(imetab) = model.unconstrained(imetab); 
end


for irxn = 1:length(fbamodel.pts) 
    gene_association{irxn} = fbamodel.pts(irxn);% sectioning string from istart to iend
    if ~isempty(gene_association{irxn})
        pt = gene_association{irxn};
        tf = strcmp(pt,fbamodel.pts);
        if any(tf)
            fbamodel.G(tf, irxn) = 1;
        else
            fbamodel.G(ipt, irxn) = 1;
            fbamodel.pts{ipt} = pt;
            ipt = ipt + 1;
        end
    end
           
end

fbamodel.metabs = fbamodel.metabs(~boundary); 
fbamodel.S = fbamodel.S(~boundary, :);
fbamodel.nmetab = length(fbamodel.metabs);
fbamodel.metabname = fbamodel.metabname(~boundary);
fbamodel.rxnname = transpose(model.rxnNames);
end

