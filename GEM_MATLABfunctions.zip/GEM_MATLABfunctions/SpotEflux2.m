function [obj_func, eflux2_flux, fbamodel] = SpotEflux2(condition,model,expression)
% SPOT produces a condition-specific metabolic flux distribution from transcriptomic data, which can be used when objective function is unknown 

% by Min Kyung Kim Oct, 21, 2015
addpath(genpath('GEMGeneration'))
addpath(genpath('FluxBalanceAnalysis'))
%load gene expression data

expression = readtable(expression);
expr{1} = table2array(expression(:,1));
expr{2} = table2array(expression(:,2:end));
expr_cols = expression.Properties.VariableNames(2:end);


%load a genome-scale metabolic model
fbamodel = mat_SPOTformat(model);

if (~all(fbamodel.vmin == 0 | fbamodel.vmin == -Inf) ...
    && ~all(fbamodel.vmax == 0 | fbamodel.vmax == Inf))
    disp('FBA model bounds must be 0 or +/- Infinity');
    return;
end

% process gene expression data based on GPR association
pts_expr = zeros(length(fbamodel.pts), length(expr_cols)); 

for i = 1:length(fbamodel.pts)
    pts = fbamodel.pts{i};
    
     
    level = 1; 
    j = 1; 
    op = [];  
    val = []; 
    
    while j <= length(pts) 
        
        if pts(j) == '('  
            level = level + 1; 
            j = j + 1; 
        
        elseif pts(j) == ')'
            newval = val(level, :);
            level = level - 1;                       
           
            if  length(op) >= level && op(level) > 0 
            
                if  op(level) == 1  
                    val(level, :) = val(level, :) + newval; 
                elseif op(level) == 2 
                    val(level, :) = min([val(level, :); newval]);
                end 
                op(level) = 0; 
            else 
                val(level, :) = newval; 
            end 
            j = j + 1; 
        
        
        elseif j+3 < length(pts) && strcmp(pts(j:(j + 3)), ' or ') 
       
            op(level) = 1; 
            j = j + 4;
        
        elseif j+4 < length(pts) && strcmp(pts(j:(j + 4)), ' and ') 
            op(level) = 2; 
            j = j + 5; 
        
        else 
            gene = pts(j:(j + 14)); % add 14 instead for ENSG genes            
            iexpr = find(strcmp(gene, expr{1})); 
            if ~isempty(iexpr) 
                newval = mean(expr{2}(iexpr, :), 1); 
            else 
                newval = Inf(1, length(expr_cols));
            end     
     
            if  length(op) >= level && op(level) > 0          
                if  op(level) == 1 
                    val(level, :) = val(level, :) + newval;  
                elseif op(level) == 2 
                    val(level, :) = min([val(level, :); newval]); 
                end 
                op(level) = 0;
            else 
                val(level, :) = newval; 
            end 
            
            j = j + 15; %add 15 for ensg genes
        end 
      
    end
  
    if ~isempty(char(fbamodel.pts(i)))
        pts_expr(i, :) = val(1, :);  
    end
      
end 

all_expr = pts_expr;

gene_data = pts_expr(:,condition); 

% max vg, s.t. Sv = 0 , 0/-Inf <= v <= 0/+Inf
brev = fbamodel.vmin < 0 & fbamodel.vmax > 0; 
birr = ~brev;
irev = find(brev);
iirr = find(birr);

fbamodel_rev = sparse(0, fbamodel.nrxn);
for i = 1:length(irev)
    fbamodel_rev(i, irev(i)) = 1;
end

fbamodel_irr = sparse(0, fbamodel.nrxn);
for i = 1:length(iirr)
    fbamodel_irr(i, iirr(i)) = 1;
end

gene_rev = fbamodel_rev*gene_data;
gene_rev(gene_rev == inf) = 0;
gene_irr = fbamodel_irr*gene_data;
gene_irr(gene_irr == inf) = 0;

S_rev = fbamodel.S*fbamodel_rev';
S_irr = fbamodel.S*fbamodel_irr';

vmin_rev =  fbamodel_rev*fbamodel.vmin;
vmax_rev =  fbamodel_rev*fbamodel.vmax;
vmin_irr =  fbamodel_irr*fbamodel.vmin;
vmax_irr =  fbamodel_irr*fbamodel.vmax;

model1.A = [S_irr S_rev -S_rev] ; 
model1.sense = char('='* ones(size(model1.A,1), 1)); 
model1.rhs = [zeros(fbamodel.nmetab,1)] ; 
model1.modelsense = 'max'; 
model1.lb = [vmin_irr; zeros(length(vmin_rev),1); zeros(length(vmin_rev),1)];
model1.ub = [vmax_irr; vmax_rev; -vmin_rev]; 
model1.obj = [gene_irr; gene_rev ; gene_rev]; 

% % |v|^2 <= 1 => quadratic constraint
model1.quadcon(1).Qc = speye(length(model1.lb)); 
model1.quadcon(1).q =  zeros(length(model1.lb), 1);  
model1.quadcon(1).rhs = 1; 

params1.outputflag = 0; %in order to shut off Gurobi output
params1.BarHomogeneous = 1; %setting homogeneous barrier algorithm to 1 forces it on.
result1 = gurobi(model1, params1);

maxvg_v = result1.x; % resulting flux distribution (decomposed network)

v_irr = maxvg_v(1:length(vmin_irr));
f_v_rev = maxvg_v(length(vmin_irr)+1: length(vmin_irr) + length(vmin_rev));
b_v_rev = maxvg_v(length(vmin_irr) + length(vmin_rev) + 1: length(maxvg_v));
v_rev = f_v_rev - b_v_rev;

spot_flux = fbamodel_irr'*v_irr + fbamodel_rev'*v_rev;


obj_func_v_irr = model1.obj(1:length(vmin_irr));
obj_func_f_v_rev = model1.obj(length(vmin_irr)+1: length(vmin_irr) + length(vmin_rev));
obj_func_b_v_rev = model1.obj(length(vmin_irr) + length(vmin_rev) + 1: length(model1.obj));
obj_func_v_rev = obj_func_f_v_rev - obj_func_b_v_rev;
obj_func = fbamodel_irr'*obj_func_v_irr + fbamodel_rev'*obj_func_v_rev;
fbamodel.f = obj_func;

%Step 1 of E-Flux2: peform E-Flux
%change the lower and upper bounds of each reaction using the gene expression data 
fbamodel.vmax = gene_data ;  
fbamodel.vmin(fbamodel.vmin ~= 0) = -gene_data(fbamodel.vmin ~= 0, 1);
eflux = flux_balance(fbamodel, true);

%Step 2 of E-Flux2: minimize l2 norm
model2.A = [fbamodel.S;fbamodel.f'] ; 
model2.sense = char('='* ones(size(model2.A,1), 1)); 
model2.rhs = [zeros(fbamodel.nmetab,1); fbamodel.f'*eflux] ; % maintain maximized biomass flux value calculated in step 1
model2.modelsense = 'min'; % max = -1, min = 1 
model2.lb = fbamodel.vmin;
model2.ub = fbamodel.vmax;
model2.Q = sparse(diag(ones(fbamodel.nrxn,1)));
model2.obj = zeros(fbamodel.nrxn,1);

fbamodel.lb = model2.lb;
fbamodel.ub = model2.ub;
fbamodel.obj = model2.obj;


params2.outputflag = 0; %in order to shut off Gurobi output
params2.BarHomogeneous = 1; %setting homogeneous barrier algorithm to 1 forces it on.

result2 = gurobi(model2, params2);
eflux2_flux = result2.x;

end
