
%flux balance analysis
% by Desmond S. Lun Feb, 26, 2013

function [v, fmax, fmin] = flux_balance(fbamodel, quiet)

if nargin < 2
    quiet = false;
end

nrxn   = fbamodel.nrxn;
nmetab = fbamodel.nmetab;

c = fbamodel.f;
lb = fbamodel.vmin;
ub = fbamodel.vmax;
   
Aeq = [ fbamodel.S                                                                                                               
        sparse(1:nnz(~fbamodel.present), find(~fbamodel.present), ones(nnz(~fbamodel.present), 1), nnz(~fbamodel.present), nrxn) ];
beq = [ zeros(nmetab, 1);
        zeros(nnz(~fbamodel.present), 1); ];

vartype = char('C' * ones(nrxn, 1));
            
options = optimset('Display', 'off');
            
[x, vbiomass, exitflag] = solve_milp(c, [], [], Aeq, beq, lb, ub, vartype, -1, options);

fmin = NaN;
fmax = NaN;
max_vsynth = NaN;
v = [];

if exitflag > 0
    v = x(1:nrxn);

    if nnz(fbamodel.g) > 0
        c = fbamodel.g;

        lb_nobiomass = lb;
        ub_nobiomass = ub;
        lb_nobiomass(fbamodel.f > 0) = 0;
        ub_nobiomass(fbamodel.f < 0) = 0;
        [x, max_vsynth] = solve_milp(c, [], [], Aeq, beq, lb_nobiomass, ub_nobiomass, vartype, -1, options);         

        Aeq = [ Aeq;
                fbamodel.f' ];
        beq = [ beq;
                vbiomass ];

        [x, fmin] = solve_milp(c, [], [], Aeq, beq, lb, ub, vartype, 1, options);
        [x, fmax, exitflag] = solve_milp(c, [], [], Aeq, beq, lb, ub, vartype, -1, options);
        if exitflag > 0
            v = x(1:nrxn);
        end
    end
end

if ~quiet
    fprintf('Biomass flux:    %f\n', vbiomass);
    if ~isnan(fmin)
        fprintf('Synthetic flux:  [%f, %f] of %f\n', fmin, fmax, max_vsynth);
    end
end

end

