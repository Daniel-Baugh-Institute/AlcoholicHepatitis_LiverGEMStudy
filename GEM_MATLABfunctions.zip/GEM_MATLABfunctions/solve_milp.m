
function [x, fval, exitflag] = solve_milp(f, A, b, Aeq, beq, lb, ub, vartype, sense, options)

SOLVER = 'Gurobi';

if nargin < 10
    options = optimset('Display', 'final');
end
if nargin < 9
    sense = 1;
end
if nargin < 8
    vartype = char('C' * ones(size(f)));
end
if nargin < 6
    lb = [];
    ub = [];
end
if nargin < 4
    Aeq = [];
    beq = [];
end

switch SOLVER
   
    case 'Gurobi'
        params = struct();
        params.FeasibilityTol = 1e-9;
        params.IntFeasTol = 1e-9;
        switch options.Display
            case 'off'
                params.OutputFlag = 0;
            case 'iter'
                params.DisplayInterval = 5;
            case 'final'
                params.OutputFlag = 0;
            case 'notify'
                params.OutputFlag = 0;
        end
        
        model = struct();
        model.A = [A; Aeq];
        model.obj = f;
        model.sense = [ char('<' * ones(size(A, 1), 1)); char ('=' * ones(size(Aeq, 1), 1)) ];
        model.rhs = [b; beq];
        model.lb = lb;
        model.ub = ub;     
        model.vtype = vartype;
        if sense < 0
            model.modelsense = 'max';
        else
            model.modelsense = 'min';
        end
        
        result = gurobi(model, params);
        
        if strcmp(result.status, 'OPTIMAL')
            exitflag = 1;
            x = result.x;
            fval = result.objval;
        else
            exitflag = -1;
            x = [];
            fval = NaN;
        end
end

end